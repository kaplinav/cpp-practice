﻿
#if !defined CALCULATE_H
#define CALCULATE_H

void calculateRun();


#endif
