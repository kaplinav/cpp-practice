﻿
#include "stack.h"

stack mainStack;
stack secondStack;