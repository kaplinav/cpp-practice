﻿/*
This file contains function for output the result and errors
*/

#include <cstdio>

void printError(const char *s)
{
	printf("\nError: %s", s);
}
