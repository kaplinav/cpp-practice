﻿#pragma once

void printError(const char *s);