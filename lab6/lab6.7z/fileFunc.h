﻿#pragma once
#include "BookData.h"

extern BOOK* myLibrary;
extern size_t myLibraryCount;

//Initialization
void libraryInit();
//End of work
void libraryEndOfWork();