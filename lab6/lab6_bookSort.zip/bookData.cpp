﻿#include "BookData.h"

BOOK* myLibrary = nullptr;
size_t myLibraryCount = 0;