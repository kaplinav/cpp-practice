﻿#pragma once

#include "BookData.h"

void bookSort(enSortType sortType, enSortField sortField);